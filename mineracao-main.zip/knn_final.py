import pickle
import numpy as np
from sklearn.preprocessing import StandardScaler

def carregar_modelo(caminho_modelo_pkl):
    try:
        # Carrega o modelo do arquivo .pkl
        with open(caminho_modelo_pkl, 'rb') as arquivo_pkl:
            modelo = pickle.load(arquivo_pkl)
        return modelo
    except FileNotFoundError:
        print(f"Erro: Arquivo '{caminho_modelo_pkl}' não encontrado.")
        return None
    except Exception as e:
        print(f"Ocorreu um erro ao carregar o modelo: {e}")
        return None

def normalizar_dados(dados_entrada, scaler):
    try:
        # Converte os dados de entrada para uma matriz 2D (1 amostra, várias features)
        dados_entrada = np.array(dados_entrada).reshape(1, -1)
        # Normaliza os dados de entrada
        dados_normalizados = scaler.transform(dados_entrada)
        return dados_normalizados
    except Exception as e:
        print(f"Erro ao normalizar os dados: {e}")
        return None

def fazer_predicao(modelo, dados_normalizados):
    try:
        # Faz a predição
        predicao = modelo.predict(dados_normalizados)
        return predicao[0]  # Retorna a classe prevista
    except Exception as e:
        print(f"Ocorreu um erro ao fazer a predição: {e}")
        return None

# Exemplo de uso
if __name__ == "__main__":
    caminho_modelo = 'knn_model.pkl'  # Substitua pelo caminho do arquivo do seu modelo
    caminho_scaler = 'scaler.pkl'  # Substitua pelo caminho do scaler que você salvou

    # Dados para prever (exemplo: Age, Balance, EstimatedSalary)
    dados_para_prever = [35, 12, 12]

    # Carregar o modelo treinado
    modelo = carregar_modelo(caminho_modelo)

    # Carregar o scaler usado no treinamento
    try:
        with open(caminho_scaler, 'rb') as f:
            scaler = pickle.load(f)
    except FileNotFoundError:
        print(f"Erro: Arquivo '{caminho_scaler}' não encontrado.")
        scaler = None

    # Verifica se o modelo e o scaler foram carregados corretamente
    if modelo is not None and scaler is not None:
        # Normalizar os dados de entrada
        dados_normalizados = normalizar_dados(dados_para_prever, scaler)

        if dados_normalizados is not None:
            # Fazer a predição
            resultado = fazer_predicao(modelo, dados_normalizados)

            if resultado is not None:
                print("Classe prevista:", resultado)

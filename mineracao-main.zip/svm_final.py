import pickle
import numpy as np
from sklearn.preprocessing import StandardScaler

def carregar_e_prever(dados_para_prever):
    try:
        # Carrega o modelo
        with open('svm_model.pkl', 'rb') as arquivo_modelo:
            modelo = pickle.load(arquivo_modelo)
        
        # Carrega o scaler
        with open('scaler.pkl', 'rb') as arquivo_scaler:
            scaler = pickle.load(arquivo_scaler)
        
        # Converte os dados de entrada para uma matriz 2D e normaliza
        dados_entrada = np.array(dados_para_prever).reshape(1, -1)
        dados_normalizados = scaler.transform(dados_entrada)
        
        # Faz a predição
        predicao = modelo.predict(dados_normalizados)
        
        return predicao[0]  # Retorna a classe prevista
    except FileNotFoundError as e:
        print(f"Erro: Arquivo não encontrado. {e}")
    except Exception as e:
        print(f"Ocorreu um erro: {e}")
    return None

# Exemplo de uso
#if __name__ == "__main__":
    #dados_para_prever = [35, 100000, 100000]  # Exemplo de dados de entrada

    # Chamar a função que carrega o modelo, o scaler, normaliza os dados e faz a predição
    #resultado = carregar_e_prever(dados_para_prever)
    #print(resultado)

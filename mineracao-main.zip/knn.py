import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
import pickle
import seaborn as sns
import matplotlib.pyplot as plt

# Carregando os dados
dados = pd.read_csv('bank.csv')

# Visualizando os primeiros dados
dados.head()

# Separando as features (X) e o target (Y)
X = dados[['Age', 'Balance', 'EstimatedSalary']]
Y = dados[['Class']]

# Codificando os rótulos (classe) como valores numéricos
label_encoder = LabelEncoder()
Y = label_encoder.fit_transform(Y.values.ravel())  # Transformando em uma array 1D

# Dividindo os dados em treino e teste
X_train, X_test, y_train, y_test = train_test_split(X, Y, shuffle=True, test_size=0.2, random_state=42)

# Normalizando os dados de treino e teste
scaler = StandardScaler()
scaler.fit(X_train)
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)

# Preparando o classificador KNN
knn_classifier = KNeighborsClassifier(n_neighbors=42)
knn_classifier.fit(X_train, y_train)

# Fazendo predições
y_pred = knn_classifier.predict(X_test)

# Gerando o relatório de métricas de avaliação
print(metrics.classification_report(y_test, y_pred))

# Salvando o modelo em um arquivo .pkl
with open('knn_model.pkl', 'wb') as file:
    pickle.dump(knn_classifier, file)
with open('scaler.pkl', 'wb') as file:
    pickle.dump(scaler, file)